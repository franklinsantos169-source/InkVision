/**
 * Serverless function for Vercel.
 * Endpoint: POST /api/generate
 * Expects JSON body: { prompt: "..." }
 * Requires environment variable REPLICATE_API_TOKEN set in Vercel dashboard.
 *
 * This function calls Replicate to create an image using a tattoo model.
 * IMPORTANT: keep your REPLICATE_API_TOKEN secret. Do NOT expose it to the frontend.
 */

import fetch from 'node-fetch'

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).send('Method not allowed')
    return
  }

  const { prompt } = req.body || {}
  if (!prompt) {
    res.status(400).json({ error: 'Missing prompt' })
    return
  }

  const API_TOKEN = process.env.REPLICATE_API_TOKEN
  if (!API_TOKEN) {
    res.status(500).json({ error: 'Missing server configuration (REPLICATE_API_TOKEN)' })
    return
  }

  try {
    const create = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: {
        'Content-Type':'application/json',
        'Authorization': `Token ${API_TOKEN}`,
      },
      body: JSON.stringify({
        version: 'ac732df8b0a9f96780e799f4575fba548a0d02b9b1c8f9e2028a7e7f5d0e3b8e',
        input: {
          prompt: `${prompt}, realistic tattoo design, high detail, skin tone blending, shading, no background`
        }
      })
    })
    const prediction = await create.json()

    // Poll for completion
    let result = prediction
    while (result.status !== 'succeeded' && result.status !== 'failed') {
      await new Promise(r=>setTimeout(r,3000))
      const check = await fetch(`https://api.replicate.com/v1/predictions/${prediction.id}`, {
        headers: { 'Authorization': `Token ${API_TOKEN}` }
      })
      result = await check.json()
    }

    if (result.status === 'succeeded') {
      // result.output is typically an array with URL(s)
      res.status(200).json({ output: result.output[0] })
    } else {
      res.status(500).json({ error: 'Model failed' })
    }
  } catch(err){
    console.error(err)
    res.status(500).json({ error: 'Server error' })
  }
}
