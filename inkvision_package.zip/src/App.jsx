import React, {useState} from 'react'

/*
InkVision - MVP frontend
Features:
- Input prompt for tattoo generation
- Upload photo to preview (client-side)
- Drag/rotate/scale basic controls (mobile)
- Calls serverless API /api/generate (Vercel) to request Replicate model

Before deploy:
- Add REPLICATE_API_TOKEN to your Vercel project (Environment Variable)
- Deploy to Vercel (see README)

This project is a starting point. Follow README for full deployment + Stripe instructions.
*/

export default function App(){
  const [prompt, setPrompt] = useState('')
  const [loading, setLoading] = useState(false)
  const [resultUrl, setResultUrl] = useState('')
  const [photoUrl, setPhotoUrl] = useState(null)

  // simple preview positioning state
  const [pos, setPos] = useState({x:80,y:80})
  const [rot, setRot] = useState(0)
  const [scale, setScale] = useState(1)
  const [dragging, setDragging] = useState(false)
  const [touchStart, setTouchStart] = useState(null)

  const onFile = e=>{
    const f = e.target.files?.[0]
    if(!f) return
    const url = URL.createObjectURL(f)
    setPhotoUrl(url)
  }

  const generate = async ()=>{
    if(!prompt) return alert('Describe the tattoo you want.')
    setLoading(true)
    setResultUrl('')
    try{
      const res = await fetch('/api/generate', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({prompt})
      })
      if(!res.ok){
        const txt = await res.text()
        throw new Error(txt || 'server error')
      }
      const data = await res.json()
      if(data && data.output){
        setResultUrl(data.output)
      } else {
        alert('No output from model.')
      }
    }catch(err){
      console.error(err)
      alert('Error requesting generation. See console.')
    }finally{
      setLoading(false)
    }
  }

  // touch drag handlers (mobile)
  const handleTouchStart = e=>{
    const t = e.touches[0]
    setDragging(true)
    setTouchStart({x:t.clientX - pos.x, y:t.clientY - pos.y})
  }
  const handleTouchMove = e=>{
    if(!dragging) return
    const t = e.touches[0]
    setPos({x: t.clientX - touchStart.x, y: t.clientY - touchStart.y})
  }
  const handleTouchEnd = ()=> setDragging(false)

  return (
    <div className='page'>
      <header className='header'>
        <h1>InkVision</h1>
        <p className='subtitle'>Your skin. Your art. AI-generated tattoos previewed in realistic style.</p>
      </header>

      <main className='container'>
        <section className='controls'>
          <label className='field'>
            <div className='label'>Upload photo (arm/skin)</div>
            <input type='file' accept='image/*' onChange={onFile} />
          </label>

          <label className='field'>
            <div className='label'>Describe tattoo (e.g. 'tribal lion on forearm')</div>
            <input value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder='e.g. black rose on shoulder' />
          </label>

          <div className='buttons'>
            <button onClick={generate} disabled={loading}>{loading ? 'Generating...' : 'Generate (AI)'}</button>
            <button onClick={()=>{ setResultUrl('') ; setPrompt('')}}>Reset</button>
          </div>

          <div className='premium'>
            <h3>Upgrade to Premium</h3>
            <p>Simulated plans: Monthly $2.99 • Yearly $29.99 (40% off).</p>
            <button onClick={()=>alert('Premium flow (simulated). In production connect Stripe and protect /api/generate using auth.')}>Upgrade now</button>
          </div>
        </section>

        <section className='preview'>
          <div className='previewBox'>
            {photoUrl ? <img src={photoUrl} className='background' alt='bg'/> : <div className='empty'>Upload a photo to preview</div>}
            {/* show generated tattoo or placeholder */}
            <img src={resultUrl || 'https://i.imgur.com/GsZzVZp.png'} 
                 alt='tattoo'
                 className='tattoo'
                 style={{left: pos.x, top: pos.y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${scale})`}}
                 onTouchStart={handleTouchStart}
                 onTouchMove={handleTouchMove}
                 onTouchEnd={handleTouchEnd}
            />
          </div>

          <div className='adjust'>
            <label>Rotate
              <input type='range' min='-180' max='180' value={rot} onChange={e=>setRot(e.target.value)} />
            </label>
            <label>Scale
              <input type='range' min='0.2' max='3' step='0.05' value={scale} onChange={e=>setScale(e.target.value)} />
            </label>
          </div>
        </section>
      </main>

      <footer className='footer'>
        <small>InkVision (demo) — build and deploy with Vercel. See README for deployment steps.</small>
      </footer>
    </div>
  )
}
